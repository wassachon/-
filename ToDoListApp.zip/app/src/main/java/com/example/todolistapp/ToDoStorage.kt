package com.example.todolistapp

import android.content.Context
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

class ToDoStorage(context: Context) {
    private val prefs = context.getSharedPreferences("todo_prefs", Context.MODE_PRIVATE)
    private val gson = Gson()

    fun getToDoList(): MutableList<ToDoItem> {
        val json = prefs.getString("todo_list", null) ?: return mutableListOf()
        val type = object : TypeToken<MutableList<ToDoItem>>() {}.type
        return gson.fromJson(json, type)
    }

    fun saveToDoList(list: List<ToDoItem>) {
        val json = gson.toJson(list)
        prefs.edit().putString("todo_list", json).apply()
    }
}