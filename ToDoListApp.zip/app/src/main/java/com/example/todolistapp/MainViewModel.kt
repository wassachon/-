package com.example.todolistapp

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val storage = ToDoStorage(application)
    private val _toDoList = MutableLiveData<List<ToDoItem>>()
    val toDoList: LiveData<List<ToDoItem>> get() = _toDoList

    init {
        _toDoList.value = storage.getToDoList()
    }

    fun addToDo(item: ToDoItem) {
        val current = storage.getToDoList()
        current.add(item)
        storage.saveToDoList(current)
        _toDoList.value = current
    }

    fun deleteToDo(index: Int) {
        val current = storage.getToDoList()
        current.removeAt(index)
        storage.saveToDoList(current)
        _toDoList.value = current
    }
}