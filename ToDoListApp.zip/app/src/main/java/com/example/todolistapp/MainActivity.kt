package com.example.todolistapp

import android.app.DatePickerDialog
import android.os.Bundle
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.todolistapp.databinding.ActivityMainBinding
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private val viewModel: MainViewModel by viewModels()
    private val adapter = ToDoAdapter(onDelete = { index ->
        viewModel.deleteToDo(index)
    })

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.recyclerView.layoutManager = LinearLayoutManager(this)
        binding.recyclerView.adapter = adapter

        viewModel.toDoList.observe(this) { list ->
            adapter.submitList(list.toList())
        }

        binding.btnAdd.setOnClickListener {
            val title = binding.etTitle.text.toString()
            val desc = binding.etDescription.text.toString()
            val createdDate = getCurrentDate()

            val calendar = Calendar.getInstance()
            DatePickerDialog(this, { _, year, month, day ->
                val dueDate = "%04d-%02d-%02d".format(year, month + 1, day)
                val item = ToDoItem(title, desc, createdDate, dueDate)
                viewModel.addToDo(item)
                binding.etTitle.text.clear()
                binding.etDescription.text.clear()
            }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH)).show()
        }
    }

    private fun getCurrentDate(): String {
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        return sdf.format(Date())
    }
}