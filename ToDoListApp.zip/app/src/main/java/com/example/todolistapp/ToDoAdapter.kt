package com.example.todolistapp

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.todolistapp.databinding.ItemTodoBinding

class ToDoAdapter(
    private val onDelete: (Int) -> Unit
) : RecyclerView.Adapter<ToDoAdapter.ToDoViewHolder>() {

    private var items: List<ToDoItem> = listOf()

    fun submitList(list: List<ToDoItem>) {
        items = list
        notifyDataSetChanged()
    }

    inner class ToDoViewHolder(private val binding: ItemTodoBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(item: ToDoItem, position: Int) {
            binding.tvTitle.text = item.title
            binding.tvDescription.text = item.description
            binding.tvCreated.text = "Created: ${item.createdDate}"
            binding.tvDue.text = "Due: ${item.dueDate}"
            binding.btnDelete.setOnClickListener { onDelete(position) }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ToDoViewHolder {
        val binding = ItemTodoBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ToDoViewHolder(binding)
    }

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(holder: ToDoViewHolder, position: Int) {
        holder.bind(items[position], position)
    }
}