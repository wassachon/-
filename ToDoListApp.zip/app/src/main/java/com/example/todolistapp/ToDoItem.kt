package com.example.todolistapp

data class ToDoItem(
    val title: String,
    val description: String,
    val createdDate: String,
    val dueDate: String
)